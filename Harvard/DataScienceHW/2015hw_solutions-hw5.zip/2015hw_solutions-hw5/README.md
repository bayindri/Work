# hw_solutions
